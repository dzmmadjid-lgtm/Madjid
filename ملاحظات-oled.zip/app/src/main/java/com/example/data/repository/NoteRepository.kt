package com.example.data.repository

import com.example.data.local.NoteDao
import com.example.data.model.ChecklistItem
import com.example.data.model.Note
import kotlinx.coroutines.flow.Flow

class NoteRepository(private val noteDao: NoteDao) {

    fun getActiveNotes(): Flow<List<Note>> = noteDao.getAllActiveNotes()

    fun getArchivedNotes(): Flow<List<Note>> = noteDao.getArchivedNotes()

    fun getTrashNotes(): Flow<List<Note>> = noteDao.getTrashNotes()

    fun searchNotes(query: String): Flow<List<Note>> = noteDao.searchActiveNotes(query)

    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)

    suspend fun saveNote(note: Note): Long {
        return if (note.id == 0L) {
            noteDao.insertNote(note.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
        } else {
            noteDao.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
            note.id
        }
    }

    suspend fun deleteNotePermanently(note: Note) = noteDao.deleteNote(note)

    suspend fun moveToTrash(note: Note) {
        noteDao.updateNote(note.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
    }

    suspend fun restoreFromTrash(note: Note) {
        noteDao.updateNote(note.copy(isDeleted = false, updatedAt = System.currentTimeMillis()))
    }

    suspend fun togglePin(note: Note) {
        noteDao.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
    }

    suspend fun toggleArchive(note: Note) {
        noteDao.updateNote(note.copy(isArchived = !note.isArchived, updatedAt = System.currentTimeMillis()))
    }

    suspend fun emptyTrash() = noteDao.emptyTrash()

    suspend fun seedInitialNotesIfEmpty() {
        if (noteDao.getNotesCount() == 0) {
            val sampleNotes = listOf(
                Note(
                    title = "اجتماع الفريق القادم",
                    content = "مناقشة تحديثات واجهة المستخدم وتوزيع المهام للأسبوع المقبل مع مراجعة تصاميم شاشات الـ OLED.",
                    category = "العمل",
                    colorId = "purple",
                    isPinned = true
                ),
                Note(
                    title = "قائمة التسوق الأسبوعية",
                    content = "",
                    isChecklist = true,
                    checklistJson = ChecklistItem.toJson(
                        listOf(
                            ChecklistItem(text = "حليب عضوي طازج", isDone = true),
                            ChecklistItem(text = "فواكه موسمية وتوت بري", isDone = false),
                            ChecklistItem(text = "بن قهوة مختصة إثيوبية", isDone = false),
                            ChecklistItem(text = "مكسرات وشوكولاتة داكنة", isDone = true)
                        )
                    ),
                    category = "شخصي",
                    colorId = "emerald",
                    isPinned = true
                ),
                Note(
                    title = "تطوير تطبيق OLED مخصص",
                    content = "التركيز على اللون الأسود الحقيقي (#000000) لتقليل استهلاك البطارية على شاشات AMOLED وتوفير تجربة بصرية مريحة للعين مع لمسات نيون فنية.",
                    category = "أفكار",
                    colorId = "cyan",
                    isPinned = false
                ),
                Note(
                    title = "مخطط القراءة والتعلم",
                    content = "قراءة كتاب التصميم الحديث ومتابعة أحدث تقنيات Jetpack Compose 2026.",
                    category = "دراسة",
                    colorId = "amber",
                    isPinned = false
                ),
                Note(
                    title = "أهداف الشهر القادم",
                    content = "1. ممارسة الرياضة 4 مرات أسبوعياً\n2. إنهاء مشروع تطبيق الملاحظات\n3. تنظيم المساحة المكتبية\n4. قراءة 3 كتب جديدة",
                    category = "أهداف",
                    colorId = "rose",
                    isPinned = false
                )
            )
            for (note in sampleNotes) {
                noteDao.insertNote(note)
            }
        }
    }
}
