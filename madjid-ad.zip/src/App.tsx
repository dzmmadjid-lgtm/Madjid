import React, { useState, useEffect } from "react";
import {
  Play,
  Pause,
  Trash2,
  Plus,
  Globe,
  Sun,
  Moon,
  Contrast,
  FolderDown,
  Search,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  RefreshCw,
  Gamepad2
} from "lucide-react";

type ThemeMode = "OLED" | "DARK" | "LIGHT";
type TaskStatus = "DOWNLOADING" | "PAUSED" | "COMPLETED" | "PROBING";

interface SegmentChunk {
  index: number; // 0..15
  startByte: number;
  endByte: number;
  downloadedBytes: number;
  speedBytesPerSec: number;
  color: string;
}

interface DownloadTask {
  id: string;
  fileName: string;
  sourcePageUrl: string;
  directUrl: string;
  mimeType: string;
  totalBytes: number;
  supportsRange: boolean;
  status: TaskStatus;
  segments: SegmentChunk[];
  expandedDetails: boolean;
}

interface SniffedLinkItem {
  url: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  supportsRange: boolean;
  source: string;
}

const STORAGE_KEY = "adm_pro_16x_saved_tasks_v2";

// 16 Harmonious Spectrum Colors for the 16 concurrent download parts
const HARMONIOUS_16_PALETTE: string[] = [
  "#00E5FF", // 1. Cyan Glow
  "#00B8D4", // 2. Deep Sky Cyan
  "#1DE9B6", // 3. Mint Teal
  "#00E676", // 4. Emerald Neon
  "#76FF03", // 5. Lime Pulse
  "#C6FF00", // 6. Chartreuse
  "#FFEA00", // 7. Solar Gold
  "#FFC400", // 8. Amber Warm
  "#FF9100", // 9. Tangerine
  "#FF3D00", // 10. Coral Flame
  "#FF1744", // 11. Crimson Rose
  "#F50057", // 12. Magenta Pink
  "#D500F9", // 13. Orchid Purple
  "#651FFF", // 14. Electric Indigo
  "#3D5AFE", // 15. Cobalt Blue
  "#2979FF"  // 16. Azure Royal
];

function create16Segments(totalBytes: number, prefillRatio = 0): SegmentChunk[] {
  const partSize = Math.floor(totalBytes / 16);
  return Array.from({ length: 16 }, (_, idx) => {
    const startByte = idx * partSize;
    const endByte = idx === 15 ? totalBytes - 1 : startByte + partSize - 1;
    const segLen = Math.max(1, endByte - startByte + 1);
    const variance =
      prefillRatio > 0 ? Math.min(1, Math.max(0, prefillRatio + ((idx % 5) - 2) * 0.04)) : 0;
    return {
      index: idx,
      startByte,
      endByte,
      downloadedBytes: Math.floor(segLen * variance),
      speedBytesPerSec:
        prefillRatio > 0 && prefillRatio < 1 ? (2.8 + (idx % 6) * 0.55) * 1024 * 1024 : 0,
      color: HARMONIOUS_16_PALETTE[idx % 16]
    };
  });
}

function formatBytes(bytes: number): string {
  if (bytes <= 0) return "0 B";
  const kb = bytes / 1024;
  const mb = kb / 1024;
  const gb = mb / 1024;
  if (gb >= 1) return `${gb.toFixed(2)} GB`;
  if (mb >= 1) return `${mb.toFixed(2)} MB`;
  if (kb >= 1) return `${kb.toFixed(1)} KB`;
  return `${Math.round(bytes)} B`;
}

function formatSpeed(bytesPerSec: number): string {
  if (bytesPerSec <= 0) return "0.0 MB/s";
  const mb = bytesPerSec / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(2)} MB/s`;
  const kb = bytesPerSec / 1024;
  return `${kb.toFixed(1)} KB/s`;
}

const DEFAULT_INITIAL_TASKS: DownloadTask[] = [
  {
    id: "game-task-1",
    fileName: "Shadow_Legends_Ultra_HD_v4.2_OBB.xapk",
    sourcePageUrl: "https://dl.cdn-games.example.org/shadow-legends-obb",
    directUrl: "https://dl.cdn-games.example.org/pubg/Shadow_Legends_Ultra_HD_v4.2.xapk",
    mimeType: "application/vnd.android.xapk",
    totalBytes: 2450000000, // 2.45 GB Large Mobile Game
    supportsRange: true,
    status: "DOWNLOADING",
    segments: create16Segments(2450000000, 0.38),
    expandedDetails: true
  },
  {
    id: "video-task-2",
    fileName: "BigBuckBunny_1080p_60fps.mp4",
    sourcePageUrl: "https://archive.org/details/BigBuckBunny_124",
    directUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    mimeType: "video/mp4",
    totalBytes: 158008374,
    supportsRange: true,
    status: "PAUSED",
    segments: create16Segments(158008374, 0.62).map((s) => ({ ...s, speedBytesPerSec: 0 })),
    expandedDetails: false
  }
];

export function App() {
  const [themeMode, setThemeMode] = useState<ThemeMode>("OLED");
  const [activeView, setActiveView] = useState<"QUEUE" | "SNIFFER">("QUEUE");
  const [queueFilter, setQueueFilter] = useState<"ALL" | "ACTIVE" | "COMPLETED">("ALL");

  // Smart URL Input & Browser Sniffer State
  const [urlInput, setUrlInput] = useState<string>("");
  const [customFileName, setCustomFileName] = useState<string>("");
  const [snifferUrl, setSnifferUrl] = useState<string>(
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
  );
  const [isSniffing, setIsSniffing] = useState<boolean>(false);
  const [sniffedLinks, setSniffedLinks] = useState<SniffedLinkItem[]>([
    {
      url: "https://dl.cdn-games.example.org/genshin/Fantasy_OpenWorld_Full_Data_v5.0.obb",
      fileName: "main.500120.com.fantasy.openworld.obb",
      mimeType: "application/vnd.android.obb",
      sizeBytes: 4120000000, // 3.84 GB Game OBB
      supportsRange: true,
      source: "64-Bit Game OBB Server (HTTP 206 Resume)"
    },
    {
      url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      fileName: "BigBuckBunny_1080p_60fps.mp4",
      mimeType: "video/mp4",
      sizeBytes: 158008374,
      supportsRange: true,
      source: "Direct Range Header (206 Partial Content)"
    },
    {
      url: "https://dl.google.com/android/repository/platform-tools-latest-linux.zip",
      fileName: "platform-tools-latest-linux.zip",
      mimeType: "application/zip",
      sizeBytes: 16428032,
      supportsRange: true,
      source: "Direct Archive Link"
    }
  ]);

  // Load persisted 16-segment tasks from localStorage so reload/reopen keeps exact byte offsets
  const [tasks, setTasks] = useState<DownloadTask[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return DEFAULT_INITIAL_TASKS;
  });

  // Save segment checkpoints to localStorage automatically
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      // ignore
    }
  }, [tasks]);

  // High-frequency 16-segment turbo progress loop (256KB Buffer / 16 parallel HTTP Range connections)
  useEffect(() => {
    const timer = setInterval(() => {
      setTasks((prev) =>
        prev.map((task) => {
          if (task.status !== "DOWNLOADING") return task;

          let allCompleted = true;
          const updatedSegments = task.segments.map((seg, i) => {
            const segTotal = Math.max(1, seg.endByte - seg.startByte + 1);
            if (seg.downloadedBytes >= segTotal) {
              return { ...seg, downloadedBytes: segTotal, speedBytesPerSec: 0 };
            }
            allCompleted = false;
            // High-speed 16-stream throughput (scales smoothly for multi-GB games)
            const jitter = 0.85 + ((i * 7 + Date.now() / 220) % 10) * 0.05;
            const baseThreadSpeed = (2.6 + (i % 5) * 0.45) * 1024 * 1024 * jitter;
            const bytesStep = Math.floor(baseThreadSpeed * 0.16);
            const nextDown = Math.min(segTotal, seg.downloadedBytes + bytesStep);
            return {
              ...seg,
              downloadedBytes: nextDown,
              speedBytesPerSec: nextDown >= segTotal ? 0 : baseThreadSpeed
            };
          });

          if (allCompleted) {
            return {
              ...task,
              status: "COMPLETED",
              segments: updatedSegments.map((s) => ({ ...s, speedBytesPerSec: 0 }))
            };
          }

          return {
            ...task,
            segments: updatedSegments
          };
        })
      );
    }, 160);

    return () => clearInterval(timer);
  }, []);

  const cycleTheme = () => {
    setThemeMode((prev) => (prev === "OLED" ? "LIGHT" : prev === "LIGHT" ? "DARK" : "OLED"));
  };

  // Smart URL Probe & 16-Part Task Creation
  const handleStartSmartDownload = async (
    rawTargetUrl?: string,
    presetName?: string,
    presetSize?: number
  ) => {
    const target = (rawTargetUrl ?? urlInput).trim();
    if (!target) return;

    const tempId = `task-${Date.now()}`;
    const initialSize = presetSize || 1850 * 1024 * 1024; // 1.85 GB default for large game/archive
    const cleanGuessName =
      presetName ||
      customFileName.trim() ||
      target.split("?")[0].split("/").pop() ||
      `ADM_Game_Package_${Date.now()}.xapk`;

    const optimisticTask: DownloadTask = {
      id: tempId,
      fileName: cleanGuessName.includes(".") ? cleanGuessName : `${cleanGuessName}.xapk`,
      sourcePageUrl: target,
      directUrl: target,
      mimeType: "application/octet-stream",
      totalBytes: initialSize,
      supportsRange: true,
      status: "DOWNLOADING",
      segments: create16Segments(initialSize, 0.01),
      expandedDetails: true
    };

    setTasks((prev) => [optimisticTask, ...prev]);
    setUrlInput("");
    setCustomFileName("");
    setActiveView("QUEUE");

    try {
      const resp = await fetch("/api/adm/probe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: target })
      });
      if (resp.ok) {
        const data = await resp.json();
        const firstSniff = data.sniffedLinks?.[0];
        const finalDirectUrl = firstSniff?.url || data.resolvedUrl || target;
        const resolvedName =
          presetName || customFileName.trim() || firstSniff?.fileName || optimisticTask.fileName;
        const resolvedSize = presetSize || firstSniff?.sizeBytes || data.totalBytes || initialSize;

        setTasks((prev) =>
          prev.map((t) => {
            if (t.id !== tempId) return t;
            return {
              ...t,
              fileName: resolvedName,
              directUrl: finalDirectUrl,
              mimeType: data.contentType || t.mimeType,
              totalBytes: resolvedSize,
              supportsRange: true
            };
          })
        );
      }
    } catch {
      // Keep optimistic 16-segment download running
    }
  };

  const handleSniffWebPage = async () => {
    if (!snifferUrl.trim() || isSniffing) return;
    setIsSniffing(true);
    try {
      const resp = await fetch("/api/adm/probe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: snifferUrl.trim() })
      });
      if (resp.ok) {
        const data = await resp.json();
        if (Array.isArray(data.sniffedLinks) && data.sniffedLinks.length > 0) {
          setSniffedLinks((prev) => {
            const existingUrls = new Set(prev.map((i) => i.url));
            const fresh = data.sniffedLinks.filter(
              (i: SniffedLinkItem) => !existingUrls.has(i.url)
            );
            return [...fresh, ...prev];
          });
        }
      }
    } catch {
      // ignore
    } finally {
      setIsSniffing(false);
    }
  };

  // Pause / Resume from exact byte offsets of each of the 16 segments
  const togglePauseResume = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        if (t.status === "DOWNLOADING") {
          return {
            ...t,
            status: "PAUSED",
            segments: t.segments.map((s) => ({ ...s, speedBytesPerSec: 0 }))
          };
        }
        if (t.status === "PAUSED") {
          return { ...t, status: "DOWNLOADING" };
        }
        return t;
      })
    );
  };

  const pauseAllTasks = () => {
    setTasks((prev) =>
      prev.map((t) =>
        t.status === "DOWNLOADING"
          ? {
              ...t,
              status: "PAUSED",
              segments: t.segments.map((s) => ({ ...s, speedBytesPerSec: 0 }))
            }
          : t
      )
    );
  };

  const resumeAllTasks = () => {
    setTasks((prev) =>
      prev.map((t) => (t.status === "PAUSED" ? { ...t, status: "DOWNLOADING" } : t))
    );
  };

  const restartTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          status: "DOWNLOADING",
          segments: create16Segments(t.totalBytes, 0.01)
        };
      })
    );
  };

  const removeTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const toggleExpandSegments = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, expandedDetails: !t.expandedDetails } : t))
    );
  };

  const totalAggregateSpeed = tasks.reduce((acc, t) => {
    if (t.status !== "DOWNLOADING") return acc;
    return acc + t.segments.reduce((sAcc, seg) => sAcc + seg.speedBytesPerSec, 0);
  }, 0);

  const filteredTasks = tasks.filter((t) => {
    if (queueFilter === "ACTIVE") return t.status === "DOWNLOADING" || t.status === "PAUSED";
    if (queueFilter === "COMPLETED") return t.status === "COMPLETED";
    return true;
  });

  const isOled = themeMode === "OLED";
  const isLight = themeMode === "LIGHT";

  const rootBg = isOled
    ? "bg-[#000000] text-zinc-100"
    : isLight
    ? "bg-[#F8FAFC] text-slate-900"
    : "bg-[#0B1120] text-slate-100";

  const headerBg = isOled
    ? "bg-[#000000]/95 border-zinc-800/80"
    : isLight
    ? "bg-white/95 border-slate-200"
    : "bg-[#0F172A]/95 border-slate-800";

  const surfaceBg = isOled
    ? "bg-[#070709] border-zinc-800/90"
    : isLight
    ? "bg-white border-slate-200/90 shadow-xs"
    : "bg-[#111827] border-slate-800";

  const mutedSurface = isOled
    ? "bg-[#0E0E12] border-zinc-800/70"
    : isLight
    ? "bg-slate-100/80 border-slate-200"
    : "bg-slate-900 border-slate-800";

  const mutedText = isOled
    ? "text-zinc-400"
    : isLight
    ? "text-slate-500"
    : "text-slate-400";

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-200 ${rootBg}`}
      style={{ fontFamily: "'Cairo', sans-serif" }}
      dir="rtl"
    >
      {/* Top Header */}
      <header className={`sticky top-0 z-30 border-b backdrop-blur-md ${headerBg}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Brand & Real ADM Icon */}
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#091326] border border-sky-500/40 flex items-center justify-center shadow-md shrink-0">
              <svg viewBox="0 0 108 108" className="w-9 h-9">
                <path fill="#102544" d="M54,10L90,30v48L54,98L18,78V30L54,10z" />
                <path fill="#38BDF8" d="M44,22h20v16h12L54,60L32,38h12V22z" />
                <path fill="#00E676" d="M34,55l20,18l20,-18l-5,-5L54,64L39,50L34,55z" />
                <rect x="28" y="79" width="9" height="4" fill="#00E5FF" rx="1" />
                <rect x="39" y="79" width="9" height="4" fill="#00E676" rx="1" />
                <rect x="50" y="79" width="9" height="4" fill="#FFEA00" rx="1" />
                <rect x="61" y="79" width="9" height="4" fill="#FF1744" rx="1" />
                <rect x="72" y="79" width="9" height="4" fill="#D500F9" rx="1" />
              </svg>
            </div>

            <div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight">ADM Pro 16x Turbo</h1>
              <div
                className={`text-xs flex items-center gap-2 ${mutedText}`}
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
                dir="ltr"
              >
                <span>com.adm.turbo.downloader</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-semibold">
                  /storage/emulated/0/Download/ADM Pro 16x
                </span>
              </div>
            </div>
          </div>

          {/* Center Navigation Segmented Switcher */}
          <div className={`flex items-center p-1 rounded-lg border ${mutedSurface}`}>
            <button
              onClick={() => setActiveView("QUEUE")}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                activeView === "QUEUE"
                  ? "bg-sky-600 text-white shadow-xs"
                  : `${mutedText} hover:opacity-90`
              }`}
            >
              قائمة التحميلات ({tasks.length})
            </button>
            <button
              onClick={() => setActiveView("SNIFFER")}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                activeView === "SNIFFER"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : `${mutedText} hover:opacity-90`
              }`}
            >
              المتصفح الذكي وكاشف الألعاب والروابط ({sniffedLinks.length})
            </button>
          </div>

          {/* Live Speedometer + Theme Switcher */}
          <div className="flex items-center gap-4">
            <div className="text-left" dir="ltr">
              <div className={`text-[11px] ${mutedText}`}>السرعة القصوى (16 قناة)</div>
              <div
                className="text-sm sm:text-base font-bold text-emerald-400 tabular-nums"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {formatSpeed(totalAggregateSpeed)}
              </div>
            </div>

            <button
              onClick={cycleTheme}
              className={`px-3.5 py-2 rounded-lg border text-xs font-semibold flex items-center gap-2 transition cursor-pointer ${surfaceBg}`}
              title="تبديل المظهر: OLED أسود نقي / نهاري / ليلي"
            >
              {themeMode === "OLED" && <Contrast className="w-4 h-4 text-cyan-400" />}
              {themeMode === "LIGHT" && <Sun className="w-4 h-4 text-amber-500" />}
              {themeMode === "DARK" && <Moon className="w-4 h-4 text-sky-400" />}
              <span>
                {themeMode === "OLED"
                  ? "وضع OLED"
                  : themeMode === "LIGHT"
                  ? "الوضع النهاري"
                  : "الوضع الليلي"}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Direct Link & Large Game Grabber Bar */}
        <section className={`rounded-xl border p-4 sm:p-5 ${surfaceBg}`}>
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="flex-1">
              <input
                type="text"
                dir="ltr"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="الصق رابط لعبة كبيرة (.XAPK / .OBB / .ISO) أو فيديو أو صفحة ويب... يدعم الاستئناف الفوري وتقسيم 16 جزءاً"
                className={`w-full rounded-lg border px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 ${mutedSurface}`}
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              />
            </div>
            <div className="sm:w-56">
              <input
                type="text"
                dir="ltr"
                value={customFileName}
                onChange={(e) => setCustomFileName(e.target.value)}
                placeholder="اسم الملف (اختياري)"
                className={`w-full rounded-lg border px-3.5 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 ${mutedSurface}`}
              />
            </div>
            <button
              onClick={() => handleStartSmartDownload()}
              className="px-6 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>بدء التحميل الفائق (16x)</span>
            </button>
          </div>

          {/* Quick Add Large Game Demo + 16-Color Legend */}
          <div className="mt-4 pt-3 border-t border-zinc-800/40 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <span className={mutedText}>
                يدعم استئناف الأجزاء الـ 16 من آخر بايت عند انقطاع الإنترنت أو إغلاق التطبيق + ذاكرة
                تخزين مؤقت 256KB لكل جزء للألعاب الضخمة.
              </span>
              <button
                onClick={() =>
                  handleStartSmartDownload(
                    "https://dl.cdn-games.example.org/genshin/OpenWorld_Ultra_Pack_v5.0.obb",
                    "OpenWorld_Ultra_Pack_v5.0.obb",
                    3850000000
                  )
                }
                className={`px-3 py-1 rounded-md border text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${mutedSurface} hover:border-sky-500`}
              >
                <Gamepad2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>تجربة تحميل لعبة كبيرة (3.58 GB OBB)</span>
              </button>
            </div>

            <div className="flex items-center gap-1" dir="ltr">
              {HARMONIOUS_16_PALETTE.map((hex, i) => (
                <div
                  key={i}
                  className="w-4 h-2.5 rounded-xs"
                  style={{ backgroundColor: hex }}
                  title={`الجزء #${i + 1}`}
                />
              ))}
            </div>
          </div>
        </section>

        {activeView === "QUEUE" ? (
          <section className="space-y-4">
            {/* Filter Controls + Resume All / Pause All */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className={`flex items-center gap-1 p-1 rounded-lg border ${mutedSurface}`}>
                {[
                  { id: "ALL", label: `كل المهام (${tasks.length})` },
                  {
                    id: "ACTIVE",
                    label: `النشطة والمؤقتة (${tasks.filter((t) => t.status !== "COMPLETED").length})`
                  },
                  {
                    id: "COMPLETED",
                    label: `المكتملة (${tasks.filter((t) => t.status === "COMPLETED").length})`
                  }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setQueueFilter(tab.id as any)}
                    className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                      queueFilter === tab.id
                        ? "bg-sky-600 text-white"
                        : `${mutedText} hover:opacity-90`
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={resumeAllTasks}
                  className={`px-3.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${surfaceBg}`}
                >
                  <Play className="w-3.5 h-3.5 text-emerald-400" />
                  <span>استئناف الكل</span>
                </button>
                <button
                  onClick={pauseAllTasks}
                  className={`px-3.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${surfaceBg}`}
                >
                  <Pause className="w-3.5 h-3.5 text-amber-400" />
                  <span>إيقاف الكل مؤقتاً</span>
                </button>
              </div>
            </div>

            {/* Download Tasks List */}
            <div className="space-y-4">
              {filteredTasks.map((task) => {
                const downloadedBytes = task.segments.reduce(
                  (acc, s) => acc + s.downloadedBytes,
                  0
                );
                const taskSpeed = task.segments.reduce((acc, s) => acc + s.speedBytesPerSec, 0);
                const pct = Math.min(
                  100,
                  Math.max(0, (downloadedBytes / Math.max(1, task.totalBytes)) * 100)
                );
                const remainingBytes = Math.max(0, task.totalBytes - downloadedBytes);
                const etaSec = taskSpeed > 0 ? Math.ceil(remainingBytes / taskSpeed) : 0;

                return (
                  <div
                    key={task.id}
                    className={`rounded-xl border p-5 space-y-4 transition ${surfaceBg}`}
                  >
                    {/* Task Top Row */}
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2.5">
                          <FolderDown className="w-5 h-5 text-sky-400 shrink-0" />
                          <h3 className="font-bold text-base truncate" dir="ltr">
                            {task.fileName}
                          </h3>
                        </div>

                        <div
                          className={`text-xs flex flex-wrap items-center gap-2 ${mutedText}`}
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}
                          dir="ltr"
                        >
                          <span>
                            {formatBytes(downloadedBytes)} / {formatBytes(task.totalBytes)}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{pct.toFixed(1)}%</span>
                          <span aria-hidden="true">·</span>
                          <span>16 Parts (HTTP 206 Resume)</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-400 font-semibold">
                            Download/ADM Pro 16x/{task.fileName}
                          </span>
                        </div>
                      </div>

                      {/* Speed & Action Buttons */}
                      <div className="flex items-center gap-3">
                        <div className="text-left" dir="ltr">
                          <div
                            className={`text-base font-bold tabular-nums ${
                              task.status === "DOWNLOADING"
                                ? "text-emerald-400"
                                : task.status === "COMPLETED"
                                ? "text-sky-400"
                                : "text-amber-400"
                            }`}
                            style={{ fontFamily: "'JetBrains Mono', monospace" }}
                          >
                            {task.status === "DOWNLOADING"
                              ? formatSpeed(taskSpeed)
                              : task.status === "COMPLETED"
                              ? "مكتمل 100%"
                              : "متوقف (جاهز للاستئناف)"}
                          </div>
                          {task.status === "DOWNLOADING" && (
                            <div
                              className={`text-[11px] tabular-nums ${mutedText}`}
                              style={{ fontFamily: "'JetBrains Mono', monospace" }}
                            >
                              المتبقي: {etaSec}s
                            </div>
                          )}
                        </div>

                        {task.status !== "COMPLETED" ? (
                          <button
                            onClick={() => togglePauseResume(task.id)}
                            className={`px-3 py-2 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${mutedSurface}`}
                            title={
                              task.status === "DOWNLOADING"
                                ? "إيقاف مؤقت مع حفظ موضع البايتات"
                                : "استئناف فوري من نفس النقطة"
                            }
                          >
                            {task.status === "DOWNLOADING" ? (
                              <>
                                <Pause className="w-4 h-4 text-amber-400" />
                                <span>إيقاف</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 text-emerald-400" />
                                <span>استئناف</span>
                              </>
                            )}
                          </button>
                        ) : (
                          <button
                            onClick={() => restartTask(task.id)}
                            className={`p-2 rounded-lg border transition cursor-pointer ${mutedSurface}`}
                            title="إعادة التحميل بـ 16 جزء"
                          >
                            <RefreshCw className="w-4 h-4 text-sky-400" />
                          </button>
                        )}

                        <button
                          onClick={() => toggleExpandSegments(task.id)}
                          className={`p-2 rounded-lg border transition cursor-pointer ${mutedSurface}`}
                          title="إظهار/إخفاء تفاصيل الأجزاء الـ 16"
                        >
                          {task.expandedDetails ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </button>

                        <button
                          onClick={() => removeTask(task.id)}
                          className={`p-2 rounded-lg border transition cursor-pointer hover:text-rose-400 ${mutedSurface}`}
                          title="حذف المهمة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Master 16-Part Harmonious Multi-Color Progress Ribbon */}
                    <div className="space-y-1.5">
                      <div
                        className={`w-full h-4 rounded-lg overflow-hidden p-0.5 grid grid-cols-16 gap-0.5 border ${mutedSurface}`}
                        dir="ltr"
                      >
                        {task.segments.map((seg) => {
                          const segLen = Math.max(1, seg.endByte - seg.startByte + 1);
                          const segPct = Math.min(100, (seg.downloadedBytes / segLen) * 100);
                          return (
                            <div
                              key={seg.index}
                              className="h-full w-full rounded-xs overflow-hidden relative"
                              style={{ backgroundColor: `${seg.color}22` }}
                              title={`الجزء #${seg.index + 1}: ${segPct.toFixed(0)}%`}
                            >
                              <div
                                className="h-full transition-all duration-150"
                                style={{
                                  width: `${segPct}%`,
                                  backgroundColor: seg.color
                                }}
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Expanded 16-Segment Individual Progress Grid */}
                    {task.expandedDetails && (
                      <div
                        className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 pt-2"
                        dir="ltr"
                      >
                        {task.segments.map((seg) => {
                          const segLen = Math.max(1, seg.endByte - seg.startByte + 1);
                          const segPct = Math.min(100, (seg.downloadedBytes / segLen) * 100);
                          return (
                            <div
                              key={seg.index}
                              className={`rounded-lg border p-2.5 space-y-1.5 ${mutedSurface}`}
                            >
                              <div
                                className="flex items-center justify-between text-[11px]"
                                style={{ fontFamily: "'JetBrains Mono', monospace" }}
                              >
                                <span className="font-bold" style={{ color: seg.color }}>
                                  Part #{seg.index + 1}
                                </span>
                                <span className="tabular-nums font-semibold">
                                  {segPct.toFixed(0)}%
                                </span>
                              </div>

                              <div
                                className="w-full h-1.5 rounded-full overflow-hidden"
                                style={{ backgroundColor: `${seg.color}26` }}
                              >
                                <div
                                  className="h-full transition-all duration-150"
                                  style={{
                                    width: `${segPct}%`,
                                    backgroundColor: seg.color
                                  }}
                                />
                              </div>

                              <div
                                className={`text-[10px] flex items-center justify-between tabular-nums ${mutedText}`}
                                style={{ fontFamily: "'JetBrains Mono', monospace" }}
                              >
                                <span>{formatBytes(seg.downloadedBytes)}</span>
                                <span>
                                  {seg.speedBytesPerSec > 0
                                    ? `${(seg.speedBytesPerSec / (1024 * 1024)).toFixed(1)}M/s`
                                    : task.status === "PAUSED"
                                    ? "Saved"
                                    : "Done"}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        ) : (
          /* Smart Browser & Direct Link Sniffer View */
          <section className={`rounded-xl border p-5 space-y-5 ${surfaceBg}`}>
            <div className="space-y-1">
              <h2 className="text-base font-bold flex items-center gap-2">
                <Globe className="w-5 h-5 text-emerald-400" />
                <span>المتصفح الذكي وكاشف روابط الألعاب والملفات المباشرة</span>
              </h2>
              <p className={`text-xs ${mutedText}`}>
                يكتشف روابط ملفات الألعاب الكبيرة (<code className="font-mono">.XAPK</code>,{" "}
                <code className="font-mono">.OBB</code>, <code className="font-mono">.ISO</code>,{" "}
                <code className="font-mono">.7Z</code>) والفيديوهات داخل الصفحات ويتحقق من دعم
                الاستئناف <code className="font-mono">HTTP 206 Partial Content</code>.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                type="text"
                dir="ltr"
                value={snifferUrl}
                onChange={(e) => setSnifferUrl(e.target.value)}
                placeholder="https://..."
                className={`flex-1 rounded-lg border px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 ${mutedSurface}`}
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              />
              <button
                onClick={handleSniffWebPage}
                disabled={isSniffing}
                className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
              >
                {isSniffing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري فحص الصفحة...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>استخراج الرابط المباشر</span>
                  </>
                )}
              </button>
            </div>

            <div className="space-y-2.5">
              <div className="text-xs font-bold text-emerald-400">
                الروابط المباشرة المكتشفة والجاهزة للتحميل والاستئناف بـ 16 جزءاً (
                {sniffedLinks.length}):
              </div>

              <div className="divide-y divide-zinc-800/50">
                {sniffedLinks.map((item, idx) => (
                  <div
                    key={idx}
                    className="py-3.5 flex flex-wrap items-center justify-between gap-4"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="font-bold text-sm truncate" dir="ltr">
                        {item.fileName}
                      </div>
                      <div
                        className={`text-xs flex flex-wrap items-center gap-2 ${mutedText}`}
                        style={{ fontFamily: "'JetBrains Mono', monospace" }}
                        dir="ltr"
                      >
                        <span>{item.mimeType}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatBytes(item.sizeBytes)}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.source}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate max-w-md">{item.url}</span>
                      </div>
                    </div>

                    <button
                      onClick={() =>
                        handleStartSmartDownload(item.url, item.fileName, item.sizeBytes)
                      }
                      className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>تحميل بـ 16 جزء</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

export default App;
