package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.adm.AdmDownloadEngine
import com.example.core.adm.DownloadStatus
import com.example.core.adm.DownloadTaskItem
import com.example.core.adm.SniffedMediaLink
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class IdeViewModel(application: Application) : AndroidViewModel(application) {

    val admEngine = AdmDownloadEngine(application)

    // Theme Mode: Defaults to OLED Pure Black (#000000) with support for LIGHT and DARK
    private val _themeMode = MutableStateFlow(ThemeMode.OLED)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    val downloadTasks: StateFlow<List<DownloadTaskItem>> = admEngine.tasks
    val sniffedLinks: StateFlow<List<SniffedMediaLink>> = admEngine.sniffedLinks

    private val _isProbingUrl = MutableStateFlow(false)
    val isProbingUrl: StateFlow<Boolean> = _isProbingUrl.asStateFlow()

    private val _browserCurrentUrl = MutableStateFlow("https://archive.org/details/BigBuckBunny_124")
    val browserCurrentUrl: StateFlow<String> = _browserCurrentUrl.asStateFlow()

    init {
        // Only seed default demo tasks if no persisted tasks exist on disk
        if (admEngine.tasks.value.isEmpty()) {
            // 1. Large Mobile Game XAPK + OBB (2.4 GB) to showcase multi-gigabyte 16-segment turbo engine & resume
            admEngine.start16SegmentDownload(
                urlInput = "https://dl.cdn-games.example.org/pubg/Shadow_Legends_Ultra_HD_v4.2.xapk",
                customFileName = "Shadow_Legends_Ultra_HD_v4.2_OBB.xapk",
                segmentCount = 16,
                presetTotalBytes = 2_450_000_000L // 2.45 GB Game Package
            )
            // 2. High-Speed Direct Video Stream
            admEngine.start16SegmentDownload(
                urlInput = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                customFileName = "BigBuckBunny_1080p_60fps.mp4",
                segmentCount = 16
            )
        }
    }

    fun toggleTheme() {
        _themeMode.value = when (_themeMode.value) {
            ThemeMode.OLED -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.OLED
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun startNewDownload(
        url: String,
        customFileName: String? = null,
        segments: Int = 16,
        presetTotalBytes: Long = 0L
    ) {
        if (url.isBlank()) return
        admEngine.start16SegmentDownload(url, customFileName, segments, presetTotalBytes)
    }

    fun pauseTask(taskId: String) {
        admEngine.pauseDownload(taskId)
    }

    fun resumeTask(taskId: String) {
        admEngine.resumeDownload(taskId)
    }

    fun pauseAllTasks() {
        downloadTasks.value
            .filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PROBING }
            .forEach { admEngine.pauseDownload(it.id) }
    }

    fun resumeAllTasks() {
        downloadTasks.value
            .filter { it.status == DownloadStatus.PAUSED || it.status == DownloadStatus.FAILED }
            .forEach { admEngine.resumeDownload(it.id) }
    }

    fun deleteTask(taskId: String) {
        admEngine.deleteDownload(taskId)
    }

    fun analyzeAndSniffUrl(url: String) {
        if (url.isBlank()) return
        _isProbingUrl.value = true
        _browserCurrentUrl.value = url
        viewModelScope.launch {
            admEngine.inspectAndSniffUrl(url)
            _isProbingUrl.value = false
        }
    }

    fun onWebViewResourceSniffed(url: String, title: String? = null) {
        admEngine.registerSniffedUrlFromWebView(url, title)
    }

    fun clearSniffed() {
        admEngine.clearSniffedLinks()
    }
}
