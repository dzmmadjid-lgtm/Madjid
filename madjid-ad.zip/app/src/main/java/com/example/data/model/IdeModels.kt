package com.example.data.model

enum class ThemeMode {
    DARK,
    OLED,
    LIGHT
}
