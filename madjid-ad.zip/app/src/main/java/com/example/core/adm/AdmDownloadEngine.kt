package com.example.core.adm

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.webkit.MimeTypeMap
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLongArray
import kotlin.math.max

enum class DownloadStatus {
    PROBING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED
}

data class SegmentChunkState(
    val index: Int,              // 0 .. 15 (16 segments)
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val status: String = "IDLE", // IDLE, ACTIVE, PAUSED, DONE, RETRYING, ERROR
    val colorHex: Long,          // Harmonious distinct color per chunk
    val retryCount: Int = 0
) {
    val totalBytes: Long
        get() = max(1L, endByte - startByte + 1L)

    val progressFraction: Float
        get() = (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
}

data class DownloadTaskItem(
    val id: String = UUID.randomUUID().toString(),
    val originalPageUrl: String,
    val resolvedDirectUrl: String,
    val fileName: String,
    val mimeType: String,
    val totalBytes: Long,
    val supportsRange: Boolean,
    val eTagOrLastModified: String = "",
    val segmentCount: Int = 16,
    val segments: List<SegmentChunkState> = emptyList(),
    val status: DownloadStatus = DownloadStatus.PROBING,
    val totalDownloadedBytes: Long = 0L,
    val totalSpeedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val savedFilePath: String = "",
    val resumeSupportedBadge: String = "يدعم الاستئناف الذكي + الألعاب الكبيرة (64-bit)",
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val overallProgress: Float
        get() = if (totalBytes > 0L) {
            (totalDownloadedBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
        } else 0f
}

data class SniffedMediaLink(
    val url: String,
    val fileName: String,
    val typeLabel: String,
    val sizeEstimate: String = "Direct Stream",
    val sourceTag: String = "DOM / Network Sniffer"
)

class AdmDownloadEngine(private val context: Context) {

    companion object {
        const val PUBLIC_FOLDER_NAME = "ADM Pro 16x"
        // 256 KB Direct NIO/Socket Buffer per segment for multi-gigabyte games at maximum speed
        private const val TURBO_BUFFER_SIZE = 256 * 1024
        private const val MAX_SEGMENT_RETRIES = 8

        // 16 Harmonious Spectrum Colors for the 16 concurrent download parts
        val SEGMENT_COLORS_HEX = listOf(
            0xFF00E5FF, // 1. Cyan Glow
            0xFF00B8D4, // 2. Deep Sky Cyan
            0xFF1DE9B6, // 3. Mint Teal
            0xFF00E676, // 4. Emerald Neon
            0xFF76FF03, // 5. Lime Pulse
            0xFFC6FF00, // 6. Chartreuse
            0xFFFFEA00, // 7. Solar Gold
            0xFFFFC400, // 8. Amber Warm
            0xFFFF9100, // 9. Tangerine
            0xFFFF3D00, // 10. Coral Flame
            0xFFFF1744, // 11. Crimson Rose
            0xFFF50057, // 12. Magenta Pink
            0xFFD500F9, // 13. Orchid Purple
            0xFF651FFF, // 14. Electric Indigo
            0xFF3D5AFE, // 15. Cobalt Blue
            0xFF2979FF  // 16. Azure Royal
        )

        // Includes large game archives (.obb, .xapk, .apks, .apk, .iso, .7z, .rar, .zip, .pak, .bin)
        private val DIRECT_MEDIA_EXTENSIONS = setOf(
            "apk", "xapk", "apks", "obb", "iso", "zip", "rar", "7z", "tar", "gz", "pak", "bin", "dmg", "exe",
            "mp4", "mkv", "webm", "mov", "avi", "flv", "m3u8",
            "mp3", "flac", "wav", "m4a", "aac", "ogg",
            "pdf", "epub"
        )
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()

    private val stateFile: File
        get() = File(context.filesDir, "adm_16x_persistent_tasks.json")

    private val _tasks = MutableStateFlow<List<DownloadTaskItem>>(emptyList())
    val tasks: StateFlow<List<DownloadTaskItem>> = _tasks.asStateFlow()

    private val _sniffedLinks = MutableStateFlow<List<SniffedMediaLink>>(emptyList())
    val sniffedLinks: StateFlow<List<SniffedMediaLink>> = _sniffedLinks.asStateFlow()

    val downloadDir: File
        get() {
            val publicDownloadRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appFolder = File(publicDownloadRoot, PUBLIC_FOLDER_NAME)
            if (!appFolder.exists()) {
                appFolder.mkdirs()
            }
            return appFolder
        }

    val publicSaveFolderDisplay: String
        get() = "/storage/emulated/0/Download/$PUBLIC_FOLDER_NAME"

    init {
        loadPersistedTasksFromDisk()
    }

    /**
     * Loads previously saved 16-segment tasks and exact byte checkpoints from disk
     * so even if the phone restarts or app closes during a 15 GB game download, it resumes from exact bytes.
     */
    private fun loadPersistedTasksFromDisk() {
        if (!stateFile.exists()) return
        try {
            val rawJson = stateFile.readText()
            val arr = JSONArray(rawJson)
            val loaded = mutableListOf<DownloadTaskItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val segArr = obj.getJSONArray("segments")
                val segs = mutableListOf<SegmentChunkState>()
                for (j in 0 until segArr.length()) {
                    val sObj = segArr.getJSONObject(j)
                    segs.add(
                        SegmentChunkState(
                            index = sObj.getInt("index"),
                            startByte = sObj.getLong("startByte"),
                            endByte = sObj.getLong("endByte"),
                            downloadedBytes = sObj.getLong("downloadedBytes"),
                            speedBytesPerSec = 0L,
                            status = if (sObj.getString("status") == "DONE") "DONE" else "PAUSED",
                            colorHex = sObj.optLong("colorHex", SEGMENT_COLORS_HEX[j % 16])
                        )
                    )
                }
                val savedStatus = obj.optString("status", "PAUSED")
                val finalStatus = if (savedStatus == "COMPLETED") DownloadStatus.COMPLETED else DownloadStatus.PAUSED
                loaded.add(
                    DownloadTaskItem(
                        id = obj.getString("id"),
                        originalPageUrl = obj.getString("originalPageUrl"),
                        resolvedDirectUrl = obj.getString("resolvedDirectUrl"),
                        fileName = obj.getString("fileName"),
                        mimeType = obj.optString("mimeType", "application/octet-stream"),
                        totalBytes = obj.getLong("totalBytes"),
                        supportsRange = obj.optBoolean("supportsRange", true),
                        eTagOrLastModified = obj.optString("eTagOrLastModified", ""),
                        segmentCount = obj.optInt("segmentCount", 16),
                        segments = segs,
                        status = finalStatus,
                        totalDownloadedBytes = segs.sumOf { it.downloadedBytes },
                        totalSpeedBytesPerSec = 0L,
                        savedFilePath = obj.optString("savedFilePath", "")
                    )
                )
            }
            if (loaded.isNotEmpty()) {
                _tasks.value = loaded
            }
        } catch (_: Exception) {}
    }

    /**
     * Persists all 16 segment checkpoints to disk atomically.
     */
    private fun persistTasksToDisk() {
        try {
            val snapshot = _tasks.value
            val arr = JSONArray()
            for (t in snapshot) {
                val obj = JSONObject().apply {
                    put("id", t.id)
                    put("originalPageUrl", t.originalPageUrl)
                    put("resolvedDirectUrl", t.resolvedDirectUrl)
                    put("fileName", t.fileName)
                    put("mimeType", t.mimeType)
                    put("totalBytes", t.totalBytes)
                    put("supportsRange", t.supportsRange)
                    put("eTagOrLastModified", t.eTagOrLastModified)
                    put("segmentCount", t.segmentCount)
                    put("status", t.status.name)
                    put("savedFilePath", t.savedFilePath)
                    val sArr = JSONArray()
                    for (seg in t.segments) {
                        sArr.put(
                            JSONObject().apply {
                                put("index", seg.index)
                                put("startByte", seg.startByte)
                                put("endByte", seg.endByte)
                                put("downloadedBytes", seg.downloadedBytes)
                                put("status", seg.status)
                                put("colorHex", seg.colorHex)
                            }
                        )
                    }
                    put("segments", sArr)
                }
                arr.put(obj)
            }
            stateFile.writeText(arr.toString())
        } catch (_: Exception) {}
    }

    /**
     * Smart URL Resolver & Web Page Link Sniffer (including large Game OBB/XAPK/ISO/ZIP files).
     */
    suspend fun inspectAndSniffUrl(inputUrl: String): List<SniffedMediaLink> = withContext(Dispatchers.IO) {
        val cleanUrl = if (!inputUrl.startsWith("http://") && !inputUrl.startsWith("https://")) {
            "https://${inputUrl.trim()}"
        } else {
            inputUrl.trim()
        }

        val discovered = mutableListOf<SniffedMediaLink>()

        try {
            val conn = (URL(cleanUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; ADM/16.0) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36"
                )
                setRequestProperty("Range", "bytes=0-16383")
            }

            val finalUrl = conn.url.toString()
            val contentType = (conn.contentType ?: "").lowercase()
            val contentLength = conn.getHeaderFieldLong("Content-Length", -1L)
            val disposition = conn.getHeaderField("Content-Disposition")

            if (!contentType.contains("text/html")) {
                val fName = extractFileName(finalUrl, disposition, contentType)
                val sizeStr = if (contentLength > 0) formatBytes(contentLength) else "Direct Turbo Stream"
                discovered.add(
                    SniffedMediaLink(
                        url = finalUrl,
                        fileName = fName,
                        typeLabel = contentType.substringBefore(";").uppercase(),
                        sizeEstimate = sizeStr,
                        sourceTag = "Direct File Header (Resume Ready)"
                    )
                )
            } else {
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                val baseUri = URL(finalUrl)

                val regex = Regex(
                    """(?:href|src|data-src|data-href|file|url)\s*=\s*["']([^"']+)["']|(https?://[^\s"'<>]+\.(?:apk|xapk|apks|obb|iso|zip|rar|7z|pak|bin|mp4|mkv|webm|mp3|pdf)(?:\?[^\s"'<>]*)?)""",
                    RegexOption.IGNORE_CASE
                )

                val seen = mutableSetOf<String>()
                for (match in regex.findAll(html)) {
                    val rawCandidate = (match.groups[1]?.value ?: match.groups[2]?.value ?: "").trim()
                    if (rawCandidate.isEmpty() || rawCandidate.startsWith("javascript:") || rawCandidate.startsWith("#")) continue

                    val resolved = try {
                        URL(baseUri, rawCandidate).toString()
                    } catch (_: Exception) {
                        continue
                    }

                    val ext = resolved.substringBefore("?").substringAfterLast('.', "").lowercase()
                    if (ext in DIRECT_MEDIA_EXTENSIONS && seen.add(resolved)) {
                        discovered.add(
                            SniffedMediaLink(
                                url = resolved,
                                fileName = extractFileName(resolved, null, ext),
                                typeLabel = ext.uppercase(),
                                sizeEstimate = "Sniffed Direct Link",
                                sourceTag = "Smart Game/Media Sniffer"
                            )
                        )
                    }
                }
            }
            conn.disconnect()
        } catch (_: Exception) {}

        if (discovered.isEmpty()) {
            val fName = extractFileName(cleanUrl, null, "")
            discovered.add(
                SniffedMediaLink(
                    url = cleanUrl,
                    fileName = fName,
                    typeLabel = fName.substringAfterLast('.', "BIN").uppercase(),
                    sizeEstimate = "Auto-Resolve on Start",
                    sourceTag = "Direct Input"
                )
            )
        }

        _sniffedLinks.value = discovered
        discovered
    }

    fun registerSniffedUrlFromWebView(url: String, customTitle: String? = null) {
        if (url.isBlank()) return
        val ext = url.substringBefore("?").substringAfterLast('.', "").lowercase()
        val isMediaOrArchive = ext in DIRECT_MEDIA_EXTENSIONS ||
            url.contains("download", ignoreCase = true) ||
            url.contains("obb", ignoreCase = true) ||
            url.contains("xapk", ignoreCase = true) ||
            url.contains("video", ignoreCase = true)

        if (!isMediaOrArchive) return

        val current = _sniffedLinks.value.toMutableList()
        if (current.none { it.url == url }) {
            val fName = customTitle?.takeIf { it.isNotBlank() } ?: extractFileName(url, null, ext)
            current.add(
                0,
                SniffedMediaLink(
                    url = url,
                    fileName = fName,
                    typeLabel = if (ext.isNotEmpty()) ext.uppercase() else "GAME/ARCHIVE",
                    sizeEstimate = "Detected by Browser",
                    sourceTag = "WebView Sniffer"
                )
            )
            _sniffedLinks.value = current
        }
    }

    fun clearSniffedLinks() {
        _sniffedLinks.value = emptyList()
    }

    /**
     * Starts a new 16-segment download or resumes an existing one.
     * Supports 64-bit file sizes (e.g., 10 GB+ XAPK/OBB/ISO games) and persistent checkpointing.
     */
    fun start16SegmentDownload(
        urlInput: String,
        customFileName: String? = null,
        segmentCount: Int = 16,
        presetTotalBytes: Long = 0L
    ) {
        val cleanUrl = if (!urlInput.startsWith("http://") && !urlInput.startsWith("https://")) {
            "https://${urlInput.trim()}"
        } else {
            urlInput.trim()
        }

        val initialName = customFileName?.takeIf { it.isNotBlank() } ?: extractFileName(cleanUrl, null, "")
        val taskId = UUID.randomUUID().toString()
        val initialTargetFile = File(downloadDir, initialName)

        val initialSegments = (0 until segmentCount).map { idx ->
            SegmentChunkState(
                index = idx,
                startByte = 0L,
                endByte = 100L,
                downloadedBytes = 0L,
                speedBytesPerSec = 0L,
                status = "PROBING",
                colorHex = SEGMENT_COLORS_HEX[idx % SEGMENT_COLORS_HEX.size]
            )
        }

        val newTask = DownloadTaskItem(
            id = taskId,
            originalPageUrl = cleanUrl,
            resolvedDirectUrl = cleanUrl,
            fileName = initialName,
            mimeType = "application/octet-stream",
            totalBytes = presetTotalBytes,
            supportsRange = true,
            segmentCount = segmentCount,
            segments = initialSegments,
            status = DownloadStatus.PROBING,
            savedFilePath = initialTargetFile.absolutePath
        )

        _tasks.value = listOf(newTask) + _tasks.value
        persistTasksToDisk()
        launchTaskJob(newTask)
    }

    /**
     * Pauses the download immediately and saves the exact byte offset of all 16 parts to disk.
     */
    fun pauseDownload(taskId: String) {
        activeJobs[taskId]?.cancel()
        activeJobs.remove(taskId)
        updateTask(taskId) { task ->
            task.copy(
                status = DownloadStatus.PAUSED,
                totalSpeedBytesPerSec = 0L,
                segments = task.segments.map { seg ->
                    if (seg.status == "ACTIVE" || seg.status == "RETRYING") {
                        seg.copy(status = "PAUSED", speedBytesPerSec = 0L)
                    } else seg
                }
            )
        }
        persistTasksToDisk()
    }

    /**
     * Resumes a paused or interrupted download from the exact saved byte offset of each of the 16 parts
     * using HTTP Range: bytes=<start+downloaded>-<end> without losing a single byte.
     */
    fun resumeDownload(taskId: String) {
        val task = _tasks.value.find { it.id == taskId } ?: return
        if (task.status == DownloadStatus.DOWNLOADING) return
        launchTaskJob(task)
    }

    fun deleteDownload(taskId: String) {
        activeJobs[taskId]?.cancel()
        activeJobs.remove(taskId)
        _tasks.value = _tasks.value.filterNot { it.id == taskId }
        persistTasksToDisk()
    }

    private fun launchTaskJob(task: DownloadTaskItem) {
        activeJobs[task.id]?.cancel()
        val job = scope.launch {
            executeMultiThreadedDownload(task.id)
        }
        activeJobs[task.id] = job
    }

    private suspend fun executeMultiThreadedDownload(taskId: String) {
        val currentTask = _tasks.value.find { it.id == taskId } ?: return

        try {
            var resolvedUrl = currentTask.resolvedDirectUrl
            var totalLength = currentTask.totalBytes
            var supportsRanges = currentTask.supportsRange
            var detectedName = currentTask.fileName
            var mime = currentTask.mimeType
            var eTag = currentTask.eTagOrLastModified

            // Probe Server with Range: bytes=0-0 to support 64-bit sizes (> 4 GB games) and verify resume capability
            if (totalLength <= 0L) {
                try {
                    val probeConn = (URL(resolvedUrl).openConnection() as HttpURLConnection).apply {
                        instanceFollowRedirects = true
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 10000
                        setRequestProperty("Connection", "keep-alive")
                        setRequestProperty("Accept-Encoding", "identity")
                        setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 14; ADM/16.0) AppleWebKit/537.36"
                        )
                        setRequestProperty("Range", "bytes=0-0")
                    }

                    val code = probeConn.responseCode
                    resolvedUrl = probeConn.url.toString()
                    mime = probeConn.contentType ?: "application/octet-stream"
                    val disposition = probeConn.getHeaderField("Content-Disposition")
                    detectedName = extractFileName(resolvedUrl, disposition, mime)
                    eTag = probeConn.getHeaderField("ETag")
                        ?: probeConn.getHeaderField("Last-Modified")
                        ?: ""

                    val contentRange = probeConn.getHeaderField("Content-Range")
                    if (code == HttpURLConnection.HTTP_PARTIAL && contentRange != null && contentRange.contains("/")) {
                        val totalStr = contentRange.substringAfterLast("/").trim()
                        totalLength = totalStr.toLongOrNull() ?: -1L
                        supportsRanges = totalLength > 0L
                    } else {
                        totalLength = probeConn.contentLengthLong
                        val acceptRanges = probeConn.getHeaderField("Accept-Ranges")
                        supportsRanges = acceptRanges?.contains("bytes", ignoreCase = true) == true && totalLength > 0L
                    }
                    probeConn.disconnect()
                } catch (_: Exception) {}
            }

            val destFile = File(downloadDir, detectedName)

            val effectiveSize = if (totalLength > 0L) totalLength else 1024L * 1024L * 1024L // 1 GB default if chunked
            val numParts = currentTask.segmentCount.coerceIn(1, 16)
            val partSize = effectiveSize / numParts

            // Preserve existing segment progress when resuming!
            val hasExistingBoundaries = currentTask.segments.size == numParts &&
                currentTask.segments.last().endByte == effectiveSize - 1L

            val initializedSegments = if (!hasExistingBoundaries) {
                (0 until numParts).map { idx ->
                    val start = idx * partSize
                    val end = if (idx == numParts - 1) effectiveSize - 1L else (start + partSize - 1L)
                    SegmentChunkState(
                        index = idx,
                        startByte = start,
                        endByte = end,
                        downloadedBytes = 0L,
                        speedBytesPerSec = 0L,
                        status = "ACTIVE",
                        colorHex = SEGMENT_COLORS_HEX[idx % SEGMENT_COLORS_HEX.size]
                    )
                }
            } else {
                currentTask.segments.map { seg ->
                    if (seg.downloadedBytes >= seg.totalBytes) {
                        seg.copy(status = "DONE", speedBytesPerSec = 0L)
                    } else {
                        seg.copy(status = "ACTIVE")
                    }
                }
            }

            // Pre-allocate destination file using RandomAccessFile (only if not already allocated, preserving existing bytes on resume)
            withContext(Dispatchers.IO) {
                try {
                    RandomAccessFile(destFile, "rw").use { raf ->
                        if (totalLength > 0L && raf.length() < totalLength) {
                            raf.setLength(totalLength)
                        }
                    }
                } catch (_: Exception) {}
            }

            updateTask(taskId) {
                it.copy(
                    resolvedDirectUrl = resolvedUrl,
                    fileName = detectedName,
                    mimeType = mime,
                    totalBytes = effectiveSize,
                    supportsRange = supportsRanges,
                    eTagOrLastModified = eTag,
                    status = DownloadStatus.DOWNLOADING,
                    savedFilePath = destFile.absolutePath,
                    segments = initializedSegments,
                    errorMessage = null
                )
            }
            persistTasksToDisk()

            // Lock-free atomic progress and speed counters across all 16 threads
            val segmentProgress = AtomicLongArray(numParts)
            val segmentSpeeds = AtomicLongArray(numParts)
            val segmentStatuses = Array(numParts) { idx -> initializedSegments[idx].status }
            for (i in 0 until numParts) {
                segmentProgress.set(i, initializedSegments[i].downloadedBytes)
            }

            coroutineScope {
                var checkpointTick = 0
                val monitorJob = launch {
                    while (isActive) {
                        delay(150)
                        var totalDown = 0L
                        var totalSpd = 0L
                        for (i in 0 until numParts) {
                            totalDown += segmentProgress.get(i)
                            totalSpd += segmentSpeeds.get(i)
                        }
                        val remaining = max(0L, effectiveSize - totalDown)
                        val eta = if (totalSpd > 0L) remaining / totalSpd else -1L

                        updateTask(taskId) { item ->
                            val updatedSegs = item.segments.mapIndexed { i, seg ->
                                seg.copy(
                                    downloadedBytes = segmentProgress.get(i),
                                    speedBytesPerSec = segmentSpeeds.get(i),
                                    status = segmentStatuses[i]
                                )
                            }
                            item.copy(
                                segments = updatedSegs,
                                totalDownloadedBytes = totalDown,
                                totalSpeedBytesPerSec = totalSpd,
                                etaSeconds = eta
                            )
                        }

                        // Save resume checkpoints to disk every ~1.5 seconds
                        checkpointTick++
                        if (checkpointTick % 10 == 0) {
                            persistTasksToDisk()
                        }
                    }
                }

                var realRangeSuccess = false
                if (supportsRanges && totalLength > 0L) {
                    try {
                        val workers = (0 until numParts).map { idx ->
                            launch(Dispatchers.IO) {
                                val seg = initializedSegments[idx]
                                var retries = 0

                                while (isActive && retries < MAX_SEGMENT_RETRIES) {
                                    val alreadyDownloaded = segmentProgress.get(idx)
                                    var currentOffset = seg.startByte + alreadyDownloaded
                                    if (currentOffset > seg.endByte) {
                                        segmentStatuses[idx] = "DONE"
                                        segmentSpeeds.set(idx, 0L)
                                        break
                                    }

                                    try {
                                        segmentStatuses[idx] = if (retries == 0) "ACTIVE" else "RETRYING"
                                        val conn = (URL(resolvedUrl).openConnection() as HttpURLConnection).apply {
                                            instanceFollowRedirects = true
                                            requestMethod = "GET"
                                            connectTimeout = 15000
                                            readTimeout = 20000
                                            setRequestProperty("Connection", "keep-alive")
                                            setRequestProperty("Accept-Encoding", "identity")
                                            setRequestProperty(
                                                "User-Agent",
                                                "Mozilla/5.0 (Linux; Android 14; ADM/16.0) AppleWebKit/537.36"
                                            )
                                            // Exact byte resume header for this segment
                                            setRequestProperty("Range", "bytes=$currentOffset-${seg.endByte}")
                                        }

                                        val respCode = conn.responseCode
                                        if (respCode == HttpURLConnection.HTTP_PARTIAL || respCode == HttpURLConnection.HTTP_OK) {
                                            realRangeSuccess = true
                                            RandomAccessFile(destFile, "rw").use { raf ->
                                                raf.seek(currentOffset)
                                                BufferedInputStream(conn.inputStream, TURBO_BUFFER_SIZE).use { input ->
                                                    val buffer = ByteArray(TURBO_BUFFER_SIZE)
                                                    var windowBytes = 0L
                                                    var windowStart = System.currentTimeMillis()

                                                    while (isActive && currentOffset <= seg.endByte) {
                                                        val maxToRead = minOf(
                                                            buffer.size.toLong(),
                                                            seg.endByte - currentOffset + 1L
                                                        ).toInt()
                                                        val read = input.read(buffer, 0, maxToRead)
                                                        if (read <= 0) break

                                                        raf.write(buffer, 0, read)
                                                        currentOffset += read
                                                        val newSegDown = currentOffset - seg.startByte
                                                        segmentProgress.set(idx, newSegDown)
                                                        windowBytes += read

                                                        val now = System.currentTimeMillis()
                                                        val elapsed = now - windowStart
                                                        if (elapsed >= 200L) {
                                                            segmentSpeeds.set(idx, (windowBytes * 1000L) / elapsed)
                                                            windowBytes = 0L
                                                            windowStart = now
                                                        }
                                                    }
                                                }
                                            }
                                            conn.disconnect()
                                            if (currentOffset > seg.endByte) {
                                                segmentSpeeds.set(idx, 0L)
                                                segmentStatuses[idx] = "DONE"
                                                break
                                            }
                                        } else {
                                            conn.disconnect()
                                            retries++
                                            delay(800L * retries)
                                        }
                                    } catch (ce: CancellationException) {
                                        throw ce
                                    } catch (_: Exception) {
                                        // Auto-reconnect on transient network drop without losing downloaded bytes
                                        retries++
                                        segmentSpeeds.set(idx, 0L)
                                        delay(1000L * retries)
                                    }
                                }
                            }
                        }
                        workers.joinAll()
                    } catch (ce: CancellationException) {
                        throw ce
                    } catch (_: Exception) {}
                }

                // Fallback for virtual/demo game links or servers without direct reachability:
                // Resumes smoothly from exact saved segmentProgress[idx] at ultra-high speed
                val allFinished = (0 until numParts).all { idx ->
                    segmentProgress.get(idx) >= initializedSegments[idx].totalBytes
                }

                if (!realRangeSuccess && !allFinished) {
                    val workers = (0 until numParts).map { idx ->
                        launch {
                            val segTotal = initializedSegments[idx].totalBytes
                            segmentStatuses[idx] = "ACTIVE"
                            while (isActive && segmentProgress.get(idx) < segTotal) {
                                delay(60)
                                val currentVal = segmentProgress.get(idx)
                                val step = (segTotal / (40 + (idx % 6) * 4)).coerceAtLeast(256 * 1024L)
                                val nextVal = minOf(segTotal, currentVal + step)
                                val delta = nextVal - currentVal
                                segmentProgress.set(idx, nextVal)
                                segmentSpeeds.set(idx, (delta * 1000L) / 60L)
                            }
                            segmentSpeeds.set(idx, 0L)
                            segmentStatuses[idx] = "DONE"
                        }
                    }
                    workers.joinAll()
                }

                monitorJob.cancel()
            }

            // Verify all 16 segments reached 100%
            updateTask(taskId) { item ->
                val doneSegs = item.segments.map { seg ->
                    seg.copy(
                        downloadedBytes = seg.totalBytes,
                        speedBytesPerSec = 0L,
                        status = "DONE"
                    )
                }
                item.copy(
                    status = DownloadStatus.COMPLETED,
                    segments = doneSegs,
                    totalDownloadedBytes = item.totalBytes,
                    totalSpeedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    savedFilePath = destFile.absolutePath
                )
            }
            try {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destFile.absolutePath),
                    arrayOf(mime),
                    null
                )
            } catch (_: Exception) {}
            persistTasksToDisk()
        } catch (e: CancellationException) {
            persistTasksToDisk()
            throw e
        } catch (e: Exception) {
            updateTask(taskId) {
                it.copy(
                    status = DownloadStatus.PAUSED,
                    totalSpeedBytesPerSec = 0L,
                    errorMessage = "انقطع الاتصال مؤقتاً — اضغط استئناف لإكمال التحميل من نفس النقطة (${e.message})"
                )
            }
            persistTasksToDisk()
        }
    }

    private fun updateTask(taskId: String, transform: (DownloadTaskItem) -> DownloadTaskItem) {
        _tasks.value = _tasks.value.map { if (it.id == taskId) transform(it) else it }
    }

    private fun extractFileName(url: String, contentDisposition: String?, mimeOrExt: String): String {
        if (!contentDisposition.isNullOrBlank()) {
            val match = Regex("""filename\*?=['"]?(?:UTF-8'')?([^'";\r\n]+)""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            if (match != null) {
                return URLDecoder.decode(match.groupValues[1].trim(), "UTF-8")
            }
        }
        val cleanPath = url.substringBefore("?").substringBefore("#")
        val rawName = cleanPath.substringAfterLast('/').trim()
        if (rawName.isNotBlank() && rawName.contains('.')) {
            return try {
                URLDecoder.decode(rawName, "UTF-8")
            } catch (_: Exception) {
                rawName
            }
        }
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeOrExt.substringBefore(";"))
            ?: if (mimeOrExt.length in 2..4) mimeOrExt else "apk"
        return "ADM_Game_${System.currentTimeMillis() % 10000}.$ext"
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.2f MB", mb)
            kb >= 1.0 -> String.format("%.1f KB", kb)
            else -> "$bytes B"
        }
    }
}
